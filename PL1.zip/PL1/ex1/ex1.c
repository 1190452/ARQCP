#include<stdio.h>
int main(){
  int x = 5;
  int* xPtr = &x;
  float y = *xPtr + 3;
  int vec[] = {10, 11, 12, 13};
   
  printf("Value of x: %d\nValue of y: %.2f\n", x, y);
  printf("The address of x and xptr: %p (%p)\n",&x, xPtr);
    printf("The value pointed by xptr: %d\n", *xPtr);
    printf("The address of vec: %p\n", &vec);
    printf("The values of vec [0]: %d, vec [1]: %d, vec [2]: %d and vec [3]: %d\n", *(vec),*(vec+1),*(vec+2),*(vec+3));
    printf("The addresses of vec [0]: %p, vec [1]: %p, vec [2]: %p and vec [3]: %p\n",(vec),(vec+1),(vec+2),(vec+3));
  

    
    return 0;
}
