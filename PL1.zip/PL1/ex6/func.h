#ifndef POWER_REF
#define POWER_REF

int power_ref(int *x, int y);

#endif
