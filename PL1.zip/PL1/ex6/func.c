#include <stdio.h>

void power_ref(int* x, int y){
  int i, n=1;
  for(i=1;i<=y;i++){
    n=n**x;
  }
  *x = n;
}
