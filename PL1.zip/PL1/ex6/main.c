#include <stdio.h>
#include "func.h"

int main(){
  int x=2, y=3;
  power_ref(&x,y);
  printf("The result of x^y is: %d\n",x);
  return 0;
}
