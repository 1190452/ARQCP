#include <stdio.h>
#include "func.h"

int main(){
  char str[100] = "fita metrica";
  char str1[100] = "Joao Comeu linguas";
  char str2[100] = "nunca Mais ficava pronto";
  capitalize(str);
  capitalize(str1);
  capitalize(str2);

  printf("%s\n",str);
    printf("%s\n",str1);
      printf("%s\n",str2);

  return 0;
}
