#ifndef CAPITALIZE
#define CAPITALIZE

void capitalize(char *str);


#endif
