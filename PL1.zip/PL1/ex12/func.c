#include <stdio.h>
#include <string.h>
void capitalize(char *str){
  int i=0;
  int n= strlen(str);
  if(*(str+i)>='a' && *(str+i)<='z'){
  *(str+i) = *(str+i) - 32;
  }
  for (i=1;i<n;i++){
    if(*(str+i)== ' '){
      if(*(str+i+1)>='a' && *(str+i+1)<='z'){
    *(str+i+1) = *(str+i+1) - 32;
    }
    }
  }
}

