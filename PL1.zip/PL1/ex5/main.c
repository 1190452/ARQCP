#include<stdio.h>
#include"func.h"
int main(){
  char str[]="Alexandre";
  upper2(str);
  printf("Name: %s\n", str);
    return 0;
}
