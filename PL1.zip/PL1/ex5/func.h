void upper2(char *str);
