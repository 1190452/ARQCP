void compress_shorts(short* shorts, int n_shorts, int* integers);
