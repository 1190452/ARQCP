#include <stdio.h>
void compress_shorts(short* shorts, int n_shorts, int* integers){
  int x, k=0;
  for(x=0;x<n_shorts;x=x+2){
    integers[k] = (int)(shorts[x]+shorts[x+1]);  
    k++;
 
 }
 }

