#include <stdio.h>
#include "func.h"
int main(){
  short shorts [] =  {1,2,3,4,5,6,7,8,9,10};
  short n_shorts = ((short)(sizeof(shorts) / sizeof(short)));
  int integers [n_shorts];
  int i;
  compress_shorts(shorts, n_shorts, integers);
  printf("The integer array is: ");
  for(i=0;i<(n_shorts/2);i++) {
    printf("%d ", integers[i]);
  }
   printf("\n");

  return 0;
}
