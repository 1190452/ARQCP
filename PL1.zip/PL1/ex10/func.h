#ifndef ODD_SUM
#define ODD_SUM

int odd_sum(int *p);


#endif
