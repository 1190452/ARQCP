#include <stdio.h>
#include "func.h"

int main(){
  int sum;
  int p[] = {6,6,2,1,3,7};
  sum = odd_sum(p);
  printf("The sum of the odd elements of the array is: %d\n", sum); 

  return 0;
}
