#include <stdio.h>

int odd_sum (int *p){
  int n = *(p+0);
  int i, sum=0;
  for (i=1;i<n;i++){
    if(*(p+i)%2 !=0){
      sum += *(p+i);
    }
  }

  return sum;
}
