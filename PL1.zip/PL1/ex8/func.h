#ifndef ARRAY_SORT2
#define ARRAY_SORT2

void array_sort2(int *vec, int n);


#endif
