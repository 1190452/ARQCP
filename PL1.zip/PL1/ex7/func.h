#ifndef ARRAY_SORT1
#define ARRAY_SORT1

void array_sort1(int *vec, int n);


#endif
