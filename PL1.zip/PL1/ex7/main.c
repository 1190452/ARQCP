#include <stdio.h>
#include "func.h"

int main(){
  int i;
  int vec[] = {3,2,5,4,1};
  int n = sizeof(vec)/sizeof(int);
  array_sort1(vec, n);
  printf("The sorted array is:\n");
  for(i=0;i<n;i++){
    printf("%d\n",vec[i]);
  } 


  return 0;
}
