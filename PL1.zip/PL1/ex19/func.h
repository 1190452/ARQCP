char* find_word(char* str, char* word, char* initial_addr);
