#include <stdio.h>
#include <ctype.h>
char* find_word(char* str, char* word, char* initial_addr){
  char *p;
  int i, j=0, k, starting_point = 0;

  for (i=0;str[i];i++){
    if((str+i) != initial_addr){
      starting_point++;
    }
    else
      break;
  }

  for (i=starting_point;str[i];i++){
    if(toupper(str[i]) == toupper(word[j])){
	p = (str+i);
	for(k=i, j=0;str[k] && word[j]; j++, k++){
	  if(toupper(str[k] != toupper(word[j]))){
	      break;
	    }
	}
	  if(word[j]){
	    return p;
	  }
      }
  }
  
 }

