void populate( int *vec , int num, int limit);
