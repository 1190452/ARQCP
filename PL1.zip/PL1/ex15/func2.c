#include <stdio.h>
#include "func2.h"
int num;
void inc_nsets(){
  num++;
   }
  
