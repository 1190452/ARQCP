#include <stdio.h>
int check ( int x, int y, int z){
  int bool =0;
  if(x<y && y<z){
    bool = 1;
   }
  return bool;
   } 
