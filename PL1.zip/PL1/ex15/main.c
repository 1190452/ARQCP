#include <stdio.h>
#include "func.h"
#include "func1.h"
#include "func2.h"
int main(){
  int num = 10, i;
  int vec [num];
  int limit = 10;
  populate(vec , num, limit);
  printf("Filled Vector: ");
   for(i=0; i<num; i++){
     printf("%d ",*(vec+i));
     }
   printf("\n");
  for(i=0; i<num; i++){
    int x = *(vec+i);
    int y = *(vec+i+1);
    int z = *(vec+i+2);
    int bool = check(x,y,z);
    if(bool == 1){
      inc_nsets();
    }  
  }
    
  return 0;
}
