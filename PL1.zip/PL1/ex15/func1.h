int check ( int x, int y, int z);
