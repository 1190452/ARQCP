void inc_nsets();
extern int num;
