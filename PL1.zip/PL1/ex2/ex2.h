#ifndef COPY_VEC
#define COPY_VEC

void copy_vec(int *vec1, int *vec2, int n);

#endif
