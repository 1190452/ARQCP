#include <stdio.h>
#include "ex2.h"

int main(){
  int vec1[]= {1,2,3,4,5}, vec2[5], n, i;
  n=4;
  copy_vec(vec1, vec2, n);
  printf("The values copied from vec1 to vec2 are:\n");
  for(i=0;i<n;i++){
    printf("%d\n",*(vec2+i));
  }
  return 0;
}
