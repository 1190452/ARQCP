void upper1(char *str);
