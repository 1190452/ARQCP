#include<stdio.h>
#include"func.h"
int main(){
  char str[]="Alexandre";
  upper1(str);
  printf("Name: %s\n", str);
    return 0;
}
