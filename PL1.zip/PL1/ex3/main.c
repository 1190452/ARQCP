#include "func.h"
#include <stdio.h>

int main(){
  int p[]={1,2,3,4,5,6,7,8}, num, sum;
  num = sizeof(p)/sizeof(int);
  sum = sum_even(p,num);
  printf("The sum of the even integers is: %d", sum);

  return 0;
}
