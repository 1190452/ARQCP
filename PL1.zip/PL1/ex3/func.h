#ifndef SUM_EVEN
#define SUM_EVEN

int sum_even(int *p, int num);

#endif
