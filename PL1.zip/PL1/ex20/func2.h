void find_all_words(char* str, char* word, char** addrs);
