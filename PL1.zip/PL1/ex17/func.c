#include <stdio.h>
void swap(int* vec1, int* vec2, int size){
  int aux, x;
  for(x=0;x<size;x++){
  aux = vec1[x];
  vec1[x] =  vec2[x];
  vec2[x] = aux;
 }
 }
