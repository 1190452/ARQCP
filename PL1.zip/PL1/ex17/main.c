#include <stdio.h>
#include "func.h"
int main(){
  int vec1 [] =  {1,2,3,4,5 };
  int vec2 [] =  {6,7,8,9,10 };
  int size = ((int)(sizeof(vec1) / sizeof(int)));
  int i;
  swap(vec1, vec2, size);
  printf("The first array is: ");
  for(i=0;i<size;i++) {
    printf("%d ", vec1[i]);
  }
   printf("\n");
   printf("The second array is: ");
  for(i=0;i<size;i++) {
    printf("%d ", vec2[i]);
  }
   printf("\n");
  
  

  return 0;
}
