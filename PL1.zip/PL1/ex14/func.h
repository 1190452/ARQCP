void frequencies(float *grades, int n, int *freq);
