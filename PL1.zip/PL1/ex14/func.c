#include <stdio.h>
void frequencies(float *grades, int n, int *freq){
  int i, w=0,p;
  for(i = 0; i<21; i++) {
    freq[i] = 0;
        }
  for(i = 0; i<21; i++) {
    for(p = 0; p<n; p++) {
      if((int)*(grades+p) == i) {	  
	  w++;	 
        }
	  }
    freq[i] = w;
    w=0;
      }
}
