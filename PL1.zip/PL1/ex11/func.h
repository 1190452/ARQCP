#ifndef PALINDROME
#define PALINDROME

int palindrome(char *str);


#endif
