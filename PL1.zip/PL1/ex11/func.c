#include <stdio.h>
#include <string.h>

int palindrome(char *str){
  int l =0;
  int h = strlen(str) - 1;

  while(h > 1){
    if (str[l++] != str[h--]){
	return 0;
      }
  }
    return 1;

}

