#include <stdio.h>
#include "func.h"

int main(){
  int p1, p2, p3;
  
  p1 = palindrome("abba abba");
  p2 = palindrome("Never odd or even");
  p3 = palindrome ("Hello world");

  if (p1==1){
    printf("The string 'abba abba' is a palindrome \n");
  }else{
    printf("The string 'abba abba' is not a palindrome \n");
  }

  if (p2==1){
    printf("The string 'Never odd or even' is a palindrome \n");
  }else{
    printf("The string 'Never odd or even' is not a palindrome \n");
  }

   if (p3==1){
    printf("The string 'Hello world' is a palindrome \n");
  }else{
    printf("The string 'Hello world' is not a palindrome \n");
  }

  return 0;
}
