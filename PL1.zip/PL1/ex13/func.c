#include <stdio.h>
int where_is (char *str, char c, int *p){
  int i, w=0;
  for(i = 0; p[i] != '\0'; i++) {
    p[i] = 0;
        }
  for(i = 0; str[i] != '\0'; i++) {
    if(*(str+i) == c) {
	  p[w]=i;
	  w++;
	 
        }

	  }
	
  return w;
}
