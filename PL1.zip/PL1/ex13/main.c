#include <stdio.h>
#include "func.h"

int main(){
  char str [100] = "O joao foi a rua com o cao";
  char c  = 'O';
  int p [10], x;
  int t = where_is (str, c, p);
  printf("The character '%c' appears %d times\n", c, t);
  printf("The carecter '%c' appears in this indexs: ", c);
  for(x = 0; x<t; x++) {
    printf("%d ", p[x]);
        }
   printf("\n");
  return 0;
}
