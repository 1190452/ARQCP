int sort_without_reps(int *src, int n, int *dest);
