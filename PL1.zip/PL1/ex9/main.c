#include<stdio.h>
#include"func.h"
int main(){
  int src [] = {1,1,14,7,5,5,9,18,9};
  int n =((int)(sizeof(src) / sizeof(int)));
  int dest [n] ;
  int i;
  int p = sort_without_reps(src,n,dest);
  for(i=0; i<p; i++) {
    printf("%d\n", dest[i]);
     }
    return 0;
}
