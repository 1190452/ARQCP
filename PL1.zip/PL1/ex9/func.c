#include <stdio.h>
int sort_without_reps(int *src, int n, int *dest){
  int w=0,j,i,bool=0,aux;
  for(i=0;i<n;i++){
    dest[i]=0;
    }
  
    for (i = 0; i<n ; i++) {
        for ( j= 0; j<n; j++) {
            if(src[i]== dest[j]){
                 bool = 1;
            }
        }if(bool==0){
            dest[w]=src[i];
	    w++;
        }
	bool = 0;
    }
    for(i = 0; i<w;i++){
        for(j=i+1;j<w;j++){
            if(dest[j]<dest[i]){
               aux = dest[i];
               dest[i]=dest[j];
               dest[j]=aux;
        }
        }
    }

    return w;
}
