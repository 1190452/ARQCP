#ifndef WHERE_EXISTS
#define WHERE_EXISTS

char* where_exists(char *str1, char *str2);
int compare(const char *X, const char *Y);


#endif
