#include <stdio.h>
#include <string.h>

int compare(const char *X, const char *Y)
{
	while (*X && *Y)
	{
		if (*X != *Y)
			return 0;

		X++;
		Y++;
	}

	return (*Y == '\0');
}

char* where_exists(char *str1, char *str2){
	while (*str2 != '\0')
	{
		if ((*str2 == *str2) && compare(str2, str1))
			return str2;
		str2++;
	}

	return NULL;
}
