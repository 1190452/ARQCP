#include <stdio.h>
#include "func.h"

int main(){
  char str1[] = "Lopes";
  char str2[] = "O senhor Lopes foi à caça";
  char str3[] = "Pão Pão queijo queijo";
  char str4[] = "presunto";

  printf("%s\n", where_exists(str1, str2));
  // printf("%s\n", where_exists(str3, str4));

  return 0;
}
