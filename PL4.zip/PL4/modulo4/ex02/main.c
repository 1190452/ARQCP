#include <stdio.h>
#include "asm.h"
int main(void) {
  int n = 3;
  int result;
  result = sum_n(n);
  printf("The result is: %d\n", result);
  return 0;
}
