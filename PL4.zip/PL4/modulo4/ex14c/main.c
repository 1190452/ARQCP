#include <stdio.h>
#include "asm.h"
int main(void) {
  int a = 59;
  int b = 25;
  int pos= 5;
  int result;
  result = mixed_sum(a, b,pos);
  printf("%d\n", result);
  return 0;
}
