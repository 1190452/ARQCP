#include <stdio.h>
#include "asm.h"
int main(void){

  int num = 4;
  int nbits = 5;
  rotate_left(num,nbits);
  rotate_right(num, nbits);

	
  return 0;
}
