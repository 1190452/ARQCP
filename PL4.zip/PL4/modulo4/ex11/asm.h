#ifndef ASM_H
#define ASM_H
int rotate_left(int num, int nbits);
int rotate_right(int num, int nbits);
#endif
