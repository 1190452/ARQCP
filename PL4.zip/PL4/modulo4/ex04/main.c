#include <stdio.h>
#include "asm.h"
int main(void) {
  int num1 = 5;
  int num2 = 2;
  int *smaller;
  int result;
  result = sum_smaller(num1, num2, smaller);
  printf("The sum is: %d\n", result);
  printf("The address of the smaller number is %d\n", *smaller);
  return 0;
}
