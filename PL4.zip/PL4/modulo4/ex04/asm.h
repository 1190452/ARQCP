#ifndef ASM_H
#define ASM_H
int sum_smaller(int num1, int num2, int *smaller);
#endif
