#ifndef ASM_H
#define ASM_H
int sum_multiples_x(char *vec, int x);
#endif
