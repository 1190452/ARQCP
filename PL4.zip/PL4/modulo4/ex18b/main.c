#include <stdio.h>
#include "asm.h"
int main(void) {
 int x = 1200; 
 char arr1[] = {23,66, 5, 0};
 char *vec = arr1;
 int sum = sum_multiples_x(vec, x);
  return 0;
}
