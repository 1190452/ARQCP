#ifndef ASM_H
#define ASM_H
int test_equal(char *a, char *b);
#endif
