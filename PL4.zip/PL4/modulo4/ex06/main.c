#include <stdio.h>
#include "asm.h"
int main(void) {
  char str1 [] = "salsicha";
  char str2 [] = "salsicha";
  char *a;
  char *b;
  a=str1;
  b=str2;
  int result;
  result = test_equal(a,b);
  printf("Are Equals: %d\n", result);
  return 0;
}
