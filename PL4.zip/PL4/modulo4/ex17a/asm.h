#ifndef ASM_H
#define ASM_H
void add_byte(char x, int *vec1, int *vec2) ;
#endif
