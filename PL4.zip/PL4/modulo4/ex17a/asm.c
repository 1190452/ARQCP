void add_byte(char x, int *vec1, int *vec2){
  int i=0 ,num =0, auxNum =0, size=0;
    char bit=255,aux =0, result =0;
  size = *vec1 + 1;
  *vec2 = *vec1;
  vec2++;

   for (i=1; i< size; i++){
    num = *(vec1 + i);
    auxNum = num -255;
    aux = num & bit;   
   result = aux + x;
    *vec2= result | auxNum;
     vec2++;
     aux = 0;
     result =0;
  }
}
