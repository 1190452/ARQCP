#include <stdio.h>
#include "asm.h"
int main(void) {
  char x = 5; 
  int arr1[] = {6,0xffffffff,0xff,0xfffff0ff,0xfffff8ff,0,4};
 int arr2[7];
 int *vec1 = arr1;
 int *vec2 = arr2;
  add_byte(x, vec1, vec2);
  return 0;
}
