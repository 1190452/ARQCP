#include <stdio.h>
#include "asm.h"
int main(void) {
  char x = 5; 
  int arr1[] = {3,1,2,3};
 int arr2[4];
 int *vec1 = arr1;
 int *vec2 = arr2;
  add_byte(x, vec1, vec2);
  return 0;
}
