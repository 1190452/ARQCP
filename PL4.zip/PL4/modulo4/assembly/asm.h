short atribuir_ferramenta(unsigned short esquema, short ferramenta);
int configurar_esquema(unsigned short *esquema, short *ferramentas, int n);