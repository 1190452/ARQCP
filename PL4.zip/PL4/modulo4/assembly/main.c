#include <stdio.h>
#include "asm.h"

int main() {
	int n1 = 2;
	int n2 = 3;
	
	unsigned short esquema1 = 1301;
	short ferramentas1 = {3,4};
	
	unsigned short esquema2 = 4370;
	short ferramentas2 = {1,3,5};
	
	int resultado1 = configurar_esquema(&esquema1,ferramentas1, n1);
	int resultado2 = configurar_esquema(&esquema2,ferramentas2, n2);
	
	if(resultado1 == 1 && resultado2 == 1) {
		printf("2 op com sucesso\n");
		printf("%hu\n", esquema1);
		printf("%hu\n", esquema2);
	}else if(resultado1 == 1) {
		printf("1 op com sucesso\n");
		printf("%hu\n", esquema1);
	}else if(resultado2 == 1) {
		printf("1 op com sucesso\n");
		printf("%hu\n", esquema2);
	}else {
		printf("0\n");
	}
	
	return 0;
}
	
	
	
