#include <stdio.h>
#include "asm.h"
int main(void) {
  int a = 59;
  int left = 25;
  int right = 5;
  int result;
  result = activate_bits(a, left,right);
  printf("%d\n", result);
  return 0;
}
