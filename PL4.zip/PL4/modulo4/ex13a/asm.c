int activate_bits(int a, int left, int right){
  int i;
  int bit;
  for(i=left+1;i<32;i++){
    bit = 1 << i;
     a = a|bit;	
  }

    for(i=0;i<right;i++){
      bit = 1 << i;
      a = a|bit;
  }


  return a;
}			        

