#ifndef ASM_H
#define ASM_H
int count_bits_zero(int x);
void activate_2bits(int *ptr, int pos);
#endif
