#include <stdio.h>
#include "asm.h"
int main(void) {
  int num = 55;
  int pos = 20;
  int *ptr;
  ptr =&num;
  activate_2bits(ptr, pos); 
  return 0;
}
