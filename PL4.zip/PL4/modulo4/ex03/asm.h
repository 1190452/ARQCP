#ifndef ASM_H
#define ASM_H
int greatest(int a, int b, int c);
#endif
