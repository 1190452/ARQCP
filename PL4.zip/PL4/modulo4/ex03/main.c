#include <stdio.h>
#include "asm.h"
int main(void) {
  int a=-1;
  int b = -2;
  int c = -3;
  int result;
  result = greatest(a, b, c);
  printf("The greatest number of all three is: %d\n", result);
  return 0;
}
