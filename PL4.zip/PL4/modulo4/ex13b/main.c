#include <stdio.h>
#include "asm.h"
int main(void) {
  int a = 0;
  int left = 31;
  int right = 1;
  int result;
  result = activate_bits(a, left,right);
  printf("%x\n", result);
  return 0;
}
