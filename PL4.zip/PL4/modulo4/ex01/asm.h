#ifndef ASM_H
#define ASM_H
int cube(int x);
#endif
