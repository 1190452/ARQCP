#include <stdio.h>
#include "asm.h"
int main(void) {
  int x = 3;
  int result;
  result = cube(x);
  printf("The cube of %d is: %d\n", x, result);
  return 0;
}
