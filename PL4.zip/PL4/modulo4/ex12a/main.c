#include <stdio.h>
#include "asm.h"
int main(void) {
  int num = 55;
  int pos = 20;
  int result;
  int *ptr;
  ptr =&num;
  result = activate_bit(ptr, pos);
  if (result ==1){
    printf("The bit was altered\n");
  }else if (result == 0){
     printf("The bit was not altered\n");
  } 
  return 0;
}
