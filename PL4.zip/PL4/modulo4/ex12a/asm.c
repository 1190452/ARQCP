int activate_bit(int *ptr, int pos){
  int valor;
  int bit = 1;
  bit = (bit << pos);    // move o bit com valor  1 para 20 posições para o bit apontado por ptr
  valor = *ptr & bit;   //*ptr AND 1
  *ptr = *ptr | bit;   //muda o bit 

  if (valor ==0){
    return 1;     //se valor = 0, significa que o bit apontado por ptr era 0

  }else{
    return 0;
  }
  return 0;
}			        

