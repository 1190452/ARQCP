#ifndef ASM_H
#define ASM_H
int inc_and_square(int *v1, int v2);
#endif
