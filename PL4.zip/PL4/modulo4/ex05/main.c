#include <stdio.h>
#include "asm.h"
int main(void) {
  int v1 = 5;
  int v2 = 2;
  int result;
  result = inc_and_square(&v1, v2);
  printf("The square of v2 is: %d\n", result);
  printf("The number v1 is %d\n", v1);
  return 0;
}
