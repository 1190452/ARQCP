int join_bits(int a, int b, int pos){
 int i;
 int bitA=0, join=0;
  
  for(i=0;i<pos+1;i++){
    bitA = bitA + (1 << i);
  }
  
  
  a = (a&bitA);
  b = (b&(~bitA));
  
  join = (a|b);


   return join;
}			        

