#include <stdio.h>
#include "asm.h"
int main(void) {
  int a = 59;
  int b = 25;
  int pos = 3;
  int result;
  result = join_bits(a, b,pos);
  printf("%d\n", result);
  return 0;
}
