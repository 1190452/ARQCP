#ifndef ASM_H
#define ASM_H
int greater_date(unsigned int date1, unsigned int date2);
#endif
