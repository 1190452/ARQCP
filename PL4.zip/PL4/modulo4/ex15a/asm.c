int greater_date(unsigned int date1, unsigned int date2){
  int bit=0, i, date1d=0, date2d=0, date1m=0, date2m=0, date1a=0, date2a=0;

  for (i=8; i<24;i++){
    bit = bit + (1 << i);
  }
  
  date1a = (date1 & bit);
  date2a = (date2 & bit);

  if (date1a > date2a){
    return date1;
  } else if(date2a > date1a){
    return date2;
  }

  for (i=24; i<32;i++){
       bit = bit + (1 << i);
  }

  date1m = (date1 & bit);
  date2m = (date2 & bit);

  if (date1m > date2m){
     return date1;
  } else if(date2m > date1m){
     return date2;
  }

  for (i=0; i<8;i++){
      bit = bit + (1 << i);
  }

  date1d = (date1 & bit);
  date2d = (date2 & bit);

  if (date1d > date2d){
     return date1;
  } else if(date2d > date1d){
     return date2;
  }
     
   
   return;
}
