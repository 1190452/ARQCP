#include <stdio.h>
#include "asm.h"
int main(void) {
  int date1 = 3;
  int date2 = 88;
  int result;
  result = greater_date(date1,date2); 
  printf("The greater date is %d\n", result);
  return 0;
}
