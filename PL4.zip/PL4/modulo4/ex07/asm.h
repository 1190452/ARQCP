#ifndef ASM_H
#define ASM_H
int count_even(short *vec, int n);
#endif
