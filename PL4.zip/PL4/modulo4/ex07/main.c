#include <stdio.h>
#include "asm.h"
int main(void) {
  short vec [] = {1,9,3,4,5,0,7,8};
  int n=8;
  int result;
  result = count_even(&vec,n);
  printf("Are Equals: %d\n", result);
  return 0;
}
