#include <stdio.h>
#include "asm.h"
int code = 11;
int currentSalary = 300;
int main(void) {
 int result  = new_salary();
 printf("New Salary  = %d\n", result);
  return 0;
}
