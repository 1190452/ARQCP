#include <stdio.h>
#include "asm.h"
int base = 7;
int height = 10;
int main(void) {
 int result = getArea();
 printf("Area = %d\n", result);
  return 0;
}
