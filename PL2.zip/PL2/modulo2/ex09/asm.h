#ifndef ASM_H
#define ASM_H
long long  sum_and_subtract(void);
#endif
