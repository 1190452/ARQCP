#include <stdio.h>
#include "asm.h"
char A=2;
short B=100;
int C=60,D=70;
int main(void) { 
 
  long long result = sum_and_subtract();
  printf("Result= %lld\n", result);
  return 0;
}
