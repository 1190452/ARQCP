#include <stdio.h>
#include "asm.h"
int op1=0, op2=0,res=0;
int main(void) {
  int result;
  printf("Valor op1:");
  scanf("%d",&op1);
  printf("Valor op2:");
  scanf("%d",&op2);
  result = sum();
  printf("sum = %d\n", result);
  return 0;
}
