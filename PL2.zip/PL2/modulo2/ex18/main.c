#include <stdio.h>
#include "asm.h"
int i=3;
int main(void) {
 int result = sum();
 printf("Result = %d\n", result);
	return 0;
}

