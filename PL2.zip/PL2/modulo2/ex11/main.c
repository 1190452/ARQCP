#include <stdio.h>
#include "asm.h"
int op1 = 67;
int op2 = 987;
int main(void) {
  char result;
  result = test_flags();
  if (result == 1){
    printf("One of the flags was activated\n");
  }else if (result == 0){
    printf("None of the flags was activated\n");
  }
  return 0;
}
