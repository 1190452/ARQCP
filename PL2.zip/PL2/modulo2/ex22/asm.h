#ifndef ASM_H
#define ASM_H
int f();
int f2();
int f3();
int f4();
#endif
