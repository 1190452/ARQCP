#include <stdio.h>
#include "asm.h"
int j= 11;
int i= 300;
int main(void) {
 int result  = f();
 int result2 = f2();
 int result3 = f3();
 int result4 = f4();
   printf("Result  = %d\n", result);
   printf("Result  = %d\n", result2);
   printf("Result  = %d\n", result3);
   printf("Result  = %d\n", result4);
  return 0;
}
