#include <stdio.h>
#include "asm.h"
short s = 327;

int main(){	
	printf("%d\n", s);	
	s = swapBytes();	
	printf("%d\n", s);
	
	return 0;
}
