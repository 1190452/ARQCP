#include <stdio.h>
#include "asm.h"
int A = 7;
int B = 10;
int C = 8;
int D = 2;
int main(void) {
 int result = compute();
 printf("Result = %d\n", result);
  return 0;
}
