#include <stdio.h>
#include "asm.h"
char byte1 = 5;
char byte2 = 15;
int main(){
  
	 int result = concatBytes();
	 printf("%d\n", result);
	 
	return 0;
}
