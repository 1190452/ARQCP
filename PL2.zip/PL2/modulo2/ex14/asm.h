#ifndef ASM_H
#define ASM_H
int getArea();
extern int base, height;
#endif
