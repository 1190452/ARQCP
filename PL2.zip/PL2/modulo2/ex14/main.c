#include <stdio.h>
#include "asm.h"
int main(void) {
  base = 7;
  height = 12;
 int result = getArea();
 printf("Area = %d\n", result);
  return 0;
}
