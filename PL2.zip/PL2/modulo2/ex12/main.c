#include <stdio.h>
#include "asm.h"
int A = 15;
int B = 3;
int main(void) {
  char result;
  result = isMultiple();
  if (result == 1){
    printf("A is multiple of B\n");
  }else if (result == 0){
    printf("A isn't multiple of B\n");
  }
  return 0;
}
