#include <stdio.h>
#include "asm.h"

int main(){
 char  byte1 = 0;
 char byte2 = 0;
	 
	 short result = concatBytes();
	 printf("%d\n", result);
	 
	return 0;
}
