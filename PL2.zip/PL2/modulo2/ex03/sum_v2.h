#ifndef SUM_V2
#define SUM_V2
int sum_v2(void);
#endif
