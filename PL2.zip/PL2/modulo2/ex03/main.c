#include <stdio.h>
#include "asm.h"
#include "sum_v2.h"
int op1=0, op2=0,res=0;
int main(void) {
  int result, result2;
  printf("Valor op1:");
  scanf("%d",&op1);
  printf("Valor op2:");
  scanf("%d",&op2);
  result = sum();
  result2 = sum_v2();
  printf("sum = %d\n", result);
  printf("(CONST - op1) - (CONST- op2) = %d\n", result2);
  return 0;
}
