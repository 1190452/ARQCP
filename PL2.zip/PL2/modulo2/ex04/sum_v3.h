#ifndef SUM_V3
#define SUM_V3
int sum_v3(void);
extern int op3, op4;
#endif
