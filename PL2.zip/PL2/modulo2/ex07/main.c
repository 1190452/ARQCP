#include <stdio.h>
#include "asm.h"
short s1 = 327;
short s2 = 545;

int main(){	
       
	short result  = crossSumBytes();	
	printf("%d\n", result);
	
	return 0;
}
