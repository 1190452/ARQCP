#ifndef ASM_H
#define ASM_H
short crossSumBytes(void);
extern short s1,s2;
#endif
