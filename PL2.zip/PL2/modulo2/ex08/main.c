#include <stdio.h>
#include "asm.h"

int main(){	
        printf("Valor1:");
	 scanf("%d",&s);
	 printf("Valor2:");
	 scanf("%d",&s2);
	short result  = crossSumBytes();	
	printf("%d\n", result);
	
	return 0;
}
