#include <stdio.h>
#include "asm.h"
  int op1,op2;
int main(void) {
	 printf("Valor de op1:");
	 scanf("%d",&op1);
	 printf("Valor de op2:");
	 scanf("%d",&op2);
  long long result = sum2ints();
  printf("Result= %lld\n", result);
  return 0;
}
