#include <stdio.h>
#include "asm.h"
int array[] = {3};
int num = 1;
int *ptrvec;
int sum = 0;
int main(void) {
  ptrvec = array;
  sum = vec_sum_even();
  int result = test_even();
	printf("%d\n", sum);
  if(result == 0){
   printf("Number is not even\n");
  }else{
     printf("Number is even\n");
    }
  return 0;
}
