#ifndef ASM_H
#define ASM_H
int vec_sum_even(void);
int test_even(void);
#endif
