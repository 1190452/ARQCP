#include <stdio.h>
#include "asm.h"
long long int *ptrvec;
int num = 5;
int main(void) {
  long long int array[] = {24,54,2,3,21};
  ptrvec = array;

  int resultado = vec_greater20();
    printf("%d\n", resultado);
  return 0;
}
