#include <stdio.h>
#include "asm.h"
char str[] = "a0e04060t0";
char *ptr1;
int main(void) {
  ptr1 = str;
  int counter = 0;
  counter = zero_count();
  printf("The number of zeros of the string is %d\n:", counter);
  return 0;
}
