#include <stdio.h>
#include "asm.h"
int *ptrvec;
int num = 5;
int main(void) {
  int array[] = {1,-54,-2,3,15};
  ptrvec = array;
  int sum = sum_first_byte();
  printf("%d\n", sum);
  return 0;
}
