#ifndef FREQUENCIES_H
#define FREQUENCIES_H
	void frequencies(void);
#endif