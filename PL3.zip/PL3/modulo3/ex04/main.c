#include <stdio.h>
#include "asm.h"
int num = 5;
int array[] = {1,2,3,-4,0};
int *ptrvec;
int main(void) {
  int i =0;
  ptrvec = array;
  vec_add_one();
  for (i=0; i<num; i++){
    printf("%d\n", *(array + i));
  }
  return 0;
}
