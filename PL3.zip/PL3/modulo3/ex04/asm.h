#ifndef ASM_H
#define ASM_H
void  vec_add_one();
#endif
