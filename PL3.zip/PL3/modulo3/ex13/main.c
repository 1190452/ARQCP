#include <stdio.h>
#include "asm.h"
int *ptrvec;
int num = 5;
int main(void) {
  int i=0;
  int array[] = {1,-54,-2,3,15};
  ptrvec = array;

  keep_positives();
  for(i=0; i<num;i++) {
    printf("%d\n", array[i]);
}
  return 0;
}
