#include <stdio.h>
#include "asm.h"
char str[] = "Vamos ver o FCP ao estadio do Venfica!";
char str2[100];
char *ptr1;
char *ptr2;
int main(void) {
  ptr1 = str;
  ptr2 = str2;
  str_copy_porto2();
  printf("The string copied and altered is %s\n:",str2);
  return 0;
}
