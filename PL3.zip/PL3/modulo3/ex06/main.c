#include <stdio.h>
#include "asm.h"
char str[] = "Ananas com bife";
char *ptr1;
int main(void) {
  int counter;
  ptr1 = str;
  counter = encrypt();
  printf("The number of characters changed was: %d\n", counter);
  return 0;
}
