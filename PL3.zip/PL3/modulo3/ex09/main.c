#include <stdio.h>
#include "asm.h"
int num = 5;
int x = 3;
short *ptrvec;
int main(void) {
  short array[] = {1,2,3,-4,0};
  ptrvec = array;

  short *xAddress = vec_search();
    printf("%p\n", xAddress);
  return 0;
}
