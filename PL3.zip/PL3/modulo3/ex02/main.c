#include <stdio.h>
#include "asm.h"
char str[] = "vamos ver o FCP ao dragoum!";
char str2[100];
char *ptr1;
char *ptr2;
int main(void) {
  ptr1 = str;
  ptr2 = str2;
  str_copy_porto();
  printf("The string copied and altered is %s\n:",str2);
  return 0;
}
