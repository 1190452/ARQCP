#include <stdio.h>
#include "asm.h"
#include "asm2.h"
int array[] = {1,10,60,3,6,0};
int num = 6;
int *ptrvec;
int sum=0;
int main(void) {
  int avg;
  ptrvec = array;
  sum = vec_sum();
   avg = vec_avg();

  printf("SUM = %d\n",sum);
   printf("AVG = %d\n", avg);
  return 0;
}
