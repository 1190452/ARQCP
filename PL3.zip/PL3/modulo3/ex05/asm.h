#ifndef ASM_H
#define ASM_H
int vec_sum(void);
#endif
