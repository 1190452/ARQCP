int vec_avg();


