#include <stdio.h>
#include <string.h>
#include "analisar.h"
#include <stdlib.h>

int main(void) {
  User u1;
  User u2;
  User u3;
  User *p = (User*) malloc (3* sizeof(User));
  short *c2 = (short *) malloc (1 * sizeof(short));
  
  User *u1_pointer = &u1;
  User *u2_pointer = &u2;
  User *u3_pointer = &u3;
  
  char username1 [] = "ENIO FILHO";
  char *user_u1 =  username1;
  char username2 [] = "LUIS";
  char *user_u2 =  username2;
  char username3 [] = "PORTUGAL";
  char *user_u3 =  username3;

    
  char s_code1 [20];
  char *s_code_pointer1 = s_code1;
  char s_code2 [20];
  char *s_code_pointer2 = s_code2;
  char s_code3 [20];
  char *s_code_pointer3 = s_code3;

  int s_approval1 [10];
  int *s_approval_pointer1 = s_approval1;
  int s_approval2 [10];
  int *s_approval_pointer2 = s_approval2;
  int s_approval3 [10];
  int *s_approval_pointer3 = s_approval3;
  
  short c2_array [] = {10,15,20};
  short *c2_pointer = c2_array;
  
 
  
  u1_pointer->user_name= user_u1;
  u1_pointer->s_code = s_code_pointer1;
  u1_pointer->s_approval = s_approval_pointer1;

  u2_pointer->user_name= user_u2;
  u2_pointer->s_code = s_code_pointer2;
  u2_pointer->s_approval = s_approval_pointer2;

  u3_pointer->user_name= user_u3;
  u3_pointer->s_code = s_code_pointer3;
  u3_pointer->s_approval = s_approval_pointer3;


  analisa_cadastro(u1_pointer, c2_pointer);
  analisa_cadastro(u2_pointer, c2_pointer);
  analisa_cadastro(u3_pointer, c2_pointer);
  
  p[0] = u1;
  p[1] = u2;
  p[2] = u3;
  
  printf("%s\n", u1_pointer->user_name);
  printf("%s\n", u1_pointer->s_code);
  printf("%d\n", *u1_pointer->s_approval);
  printf("%s\n", u2_pointer->user_name);
  printf("%s\n", u2_pointer->s_code);
  printf("%d\n", *u2_pointer->s_approval);
  printf("%s\n", u3_pointer->user_name);
  printf("%s\n", u3_pointer->s_code);
  printf("%d\n", *u3_pointer->s_approval);
		  
  free(p);
  free(c2);
  
  return 0;
}
