typedef struct{
char * user_name;
char * s_code;
int * s_approval; } User;

int analisa_serie(char * name, int size, short code);
void analisa_cadastro(User *u, short * codes);
