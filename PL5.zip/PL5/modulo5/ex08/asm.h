#ifndef ASM_H
#define ASM_H
#include "struct.h" 
void fill_s2(s2 *s, short vw[3], int vj, char vc[3]);
#endif
