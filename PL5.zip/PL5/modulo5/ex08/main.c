#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  s2 struc;
  s2* s = &struc;
  short vw[3] =  {1,2,3};
  int vj = 4;
  char vc [3] = "ola";
  
  fill_s2(s, vw, vj, vc);

  return 0;
}
