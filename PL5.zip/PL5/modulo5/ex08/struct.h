#ifndef MAIN_H
#define MAIN_H
   typedef struct {
     short w[3];
     int j;
     char c[3];
   } s2;
#endif
