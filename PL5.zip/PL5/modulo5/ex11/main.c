#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {

  int lines = 2; int columns = 3;
  int result = **new_matrix(lines, columns);

  printf("%d\n", result);

  return 0;
}
