#include <stdlib.h>
#include <string.h>
#include "asm.h"
int **new_matrix(int lines, int columns){
  int **mat=NULL;

  mat = (int **) malloc(lines * sizeof(int *));

  int i;
    for (i = 0; i < lines; i++){
      *(mat + i) = (int*) malloc(columns * sizeof(int));  
     }

 
  return mat;

}
