#ifndef ASM_H
#define ASM_H
#include "struct.h" 
void fill_s1(s1 *s, int vi, char vc, int vj, char vd);
#endif
