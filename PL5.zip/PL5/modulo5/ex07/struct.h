#ifndef MAIN_H
#define MAIN_H
   typedef struct {
     int i;
     char c;
     int j;
     char d;
   } s1;

#endif
