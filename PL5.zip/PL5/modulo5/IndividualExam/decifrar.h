typedef struct{
short *texto_cifrado;
int tamanho_cifrado;
char *texto_original;
}Cifra;

void decifra_par(short numero, short chave, char *c1, char *c2);

void decifra_string(Cifra *c, short chave);
