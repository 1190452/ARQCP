#include <stdio.h>
#include <string.h>
#include "decifrar.h"
#include <stdlib.h>

int main(void) {
  Cifra c1;
  Cifra c2;
  Cifra *p = (Cifra*) malloc (2* sizeof(Cifra));
  
  Cifra *c1_pointer = &c1;
  Cifra *c2_pointer = &c2;
  
  short texto_cifrado_c1 [] = {12105, 2136, 7692, 8009, 23405, 10621, 14460};
  short *tc_c1 =  texto_cifrado_c1;
  short texto_cifrado_c2 [] = {15956, 6721, 7692, 8009, 23405, 10621, 14460};
  short *tc_c2 =  texto_cifrado_c2;
   
  int tamanho_c1 = 7;
  int tamanho_c2 = 7;

  char texto_original_c1 [14];
  char texto_original_c2 [14];
  char *to_c1 = texto_original_c1;
  char *to_c2 = texto_original_c2;

  short chave = 3153;
  
  c1_pointer->texto_cifrado = tc_c1;
  c1_pointer->tamanho_cifrado = tamanho_c1;
  c1_pointer->texto_original = to_c1;

  c2_pointer->texto_cifrado = tc_c2;
  c2_pointer->tamanho_cifrado = tamanho_c2;
  c2_pointer->texto_original = to_c2;

  decifra_string(c1_pointer, chave);
  decifra_string(c2_pointer, chave);
  
  p[0] = c1;
  p[1] = c2;
  printf("%s\n", c1_pointer->texto_original);
  free(p);
  
  return 0;
}
