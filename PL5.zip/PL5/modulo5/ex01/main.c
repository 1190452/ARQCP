#include <stdio.h>
union union_u1{
char vec[32];
float a;
int b;
} u;

struct struct_s1{
char vec[32];
float a;
int b;
} s;

int main(void) {
  struct struct_s1 s1;
  union union_u1 u1;
  printf("Size of the structure: %d bytes\n",sizeof(s1));
  
  //O size da estrutura é 40, pois temos um array de chars que ocupa 32 bytes.
  //De seguida, o float irá começar no byte 32. Como 32 é multiplo de 4 nao existe problema, por isso sao mais 4 bytes
  //Como o float a começou num bit multiplo de 4 entao int b estara num bit multiplo de 4 obrigatoriamente 
  //Resultado = 32+4+4=40, pois nao ha bytes de espaçamento
  
  printf("Size of the union: %d bytes\n",sizeof(u1));
  //Resultado é 32, pois é o membro que ocupa mais bytes na union
  return 0;
}
