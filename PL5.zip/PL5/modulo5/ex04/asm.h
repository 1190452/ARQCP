#ifndef ASM_H
#define ASM_H
#include "struct.h" 
void update_address(Student *s, char *address);
#endif
