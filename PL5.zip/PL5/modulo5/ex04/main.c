#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  
        Student s;
	Student * sPointer = &s;
	char address [] = "ARQCP";

	update_address(sPointer, address);

	printf("%s\n", "Address updated!");
	printf("%s\n", sPointer->address);
  
  return 0;
}
