#include <stdlib.h>
#include <string.h>
#include "asm.h"
char *new_str(char str[80]){
  char *ptr_char = NULL;
  int i;
  int size = strlen(str) + 1;

  ptr_char = (char *) malloc(size * sizeof(char));
  
  for (i =0; i<size; i++){
    //*(ptr_char + i) = *(str + i);
    ptr_char[i] = str[i];
  }

  // free(ptr_char);
  return ptr_char;

}
