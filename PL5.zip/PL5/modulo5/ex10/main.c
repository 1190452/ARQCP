#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  char str[80] = "Hello world, my name is asdf";
  char *result = new_str(str);
  

  return 0;
}
