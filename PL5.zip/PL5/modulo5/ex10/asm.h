#ifndef ASM_H
#define ASM_H
char *new_str(char str[80]);
#endif
