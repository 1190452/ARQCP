typedef struct {
  short id ;    
  int tnprod ;  
  unsigned char * products ; /* array representing available products */
} vmachine_t ;

int load_product ( vmachine_t * vmachine , char prod );

int load_product_quantity ( vmachine_t * vmachine , char prod , int qtd );
