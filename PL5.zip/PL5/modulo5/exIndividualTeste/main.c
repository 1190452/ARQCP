#include <stdio.h>
#include <string.h>
#include "vmachine_t.h"
#include <stdlib.h>


int main(void) {
  
  vmachine_t v1;
  vmachine_t *vmachine = &v1;
  char prod = 1;
  int qtd = 5;

  int result =0;
  result = load_product(vmachine, prod);
  int product = load_product_quantity(vmachine, prod, qtd);
  
  printf("%d\n", result);
  printf("%d\n", product);
  return 0;
}
