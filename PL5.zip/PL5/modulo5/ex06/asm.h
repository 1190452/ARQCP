#ifndef ASM_H
#define ASM_H
#include "struct.h" 
int locate_greater(Student *s, int minimum, int *greater_grades);
#endif
