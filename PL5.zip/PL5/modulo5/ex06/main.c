#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  Student s;
  int i = 0;
  int minimum = 10;
  int result = 0;
  int greater_grades[10];
  Student* sPointer = &s;

  result = locate_greater(sPointer, minimum, greater_grades);


  for (i=0; i<10; i++){
    printf("%d\n", greater_grades[i]);
  }
  printf ("The number of grades greater than minimum is: %d\n", result);
	return 0;
}
