#ifndef ASM_H
#define ASM_H
#include "struct.h" 
short fun1(structB *s);
short fun2(structB *s);
short* fun3(structB *s);
short fun4(structB *s);
#endif
