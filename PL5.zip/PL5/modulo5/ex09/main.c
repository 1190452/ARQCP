#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  structB s;
  structB *sPointer = &s;
  short result1 = fun1(sPointer);
  printf("The result of fun1 is %d\n", result1);
  short result2 = fun2(sPointer);
  printf("The result of fun2 is %d\n", result2);
  short *result3 = fun3(sPointer);
  printf("The result of fun3 is %p\n", result3);
  short result4 = fun4(sPointer);
  printf("The result of fun4 is %d\n", result4);
  

  return 0;
}
