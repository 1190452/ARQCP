#include  <stdio.h>
#include <stdlib.h> 

/*  Using dynamic memory to place a 2D vector  */
/*  with this code the memory positions are not consecutive   */
/*  there is a gap between each row */ 


int main() 
{       int vec[2][3]={{1,2,3},{4,5,6}}; 
	int rows = 2; int columns = 3;
	int i,j; 
	int **mat = (int **) malloc(rows * sizeof(int *));   /* a "column" of pointers to the rows  */

	for (i = 0; i < rows; i++)  
	{
		mat[i] = (int *) malloc(columns * sizeof(int));  /* allocate memory for each row  */
		for(j=0;j<columns;j++) 
			mat[i][j]=vec[i][j];                    /*  place the elements of the row there  */
	} 

	for (i = 0; i < rows; i++)                             /*  print the elements and the addresses  */
		for(j=0;j<columns;j++) 
			printf("&mat[%d][%d]=%p  mat[%d][%d]=%d\n",i,j,&mat[i][j],i,j,mat[i][j]); 

	for (i = 0; i < rows; i++)     /*  free the memory of each row " */
		free(mat[i]);
	free(mat); 		     /*  free the "column" of pointers to the rows  */  
	return 0; 
}

