#include  <stdio.h> 

/* On  a two dimensional vector     
	vec[i] is the address of the first element of row i 
	if one uses &vec[i] the effect is the same
	and   *vec[i] is the first element of row i */ 
   	
int main() 
{       int vec[2][3]={{1,2,3},{4,5,6}}; 
	int i; 
    	for(i=0;i<2;i++)	
		printf("vec[%d]=%p &vec[%d]=%p &vec[%d][0]=%p *vec[%d]=%d\n",i,vec[i],i,&vec[i],i,&vec[i][0],i,*vec[i]);
	return 0; 
}
