#include  <stdio.h> 

/* Without row size we cannot use [ ] !!!  */   
/* Use the matrix as a "flat vector"   */

int sum_mat(int *m, int rows , int columns ) 
{ 
	int i,j; 
	int sum=0; 
        for (i=0;i<rows;i++) 		
		for (j=0;j<columns;j++) 		 
			sum=sum+*(m+(i*columns)+j);  
	return sum ;
} 
   	
int main() 
{       int vec[2][3]={{1,2,3},{4,5,6}};  
	int i,j;
        for(i=0;i<2;i++)
           for(j=0;j<3;j++)
                printf("vec[%d][%d]=%d &vec[%d][%d]=%p\n",i,j,vec[i][j],j,i,&vec[i][j]);

	printf("sum = %d\n",sum_mat(vec[0],2,3)); 
	return 0; 
}
