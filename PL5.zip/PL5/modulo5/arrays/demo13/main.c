#include <stdio.h>
#include <stdlib.h> 

/*  places a 2D vector in dynamic memory   */
/*  ensuring the elements are placed in consecutive memory positions  */

int main() { 
	int vec[2][3]={{1,2,3},{4,5,6}}; 
	int rows = 2; int columns = 3;
	int i,j; 
	int **mat = (int **) malloc(rows * sizeof(int *));   /* a "column" of pointers to the rows  */ 

	mat[0] = (int *) malloc(rows * columns * sizeof(int));  /*  all the memory needed  */
							       /* the first pointer points to the first position */ 
								 
        for (i = 1; i < rows; i++)
	    mat[i] = mat[0] + i * columns;	/*  the other pointers are calculated  */ 
						/*  with the space for a row (columns)  between them   */

	for (i = 0; i < rows; i++) 
		for(j=0;j<columns;j++) 
			mat[i][j]=vec[i][j];    /* copy the matrix to dynamic memory  */ 


	for (i = 0; i < rows; i++)		/* print the addresses and the contents */   
		for(j=0;j<columns;j++) 
			printf("&mat[%d][%d]=%p  mat[%d][%d]=%d\n",i,j,&mat[i][j],i,j,mat[i][j]); 

	free(mat[0]);     /*  free the space of the matrix  */
	free(mat); 	 /*  free the "column" of pointers to the rows  */ 
	return 0; 
}

