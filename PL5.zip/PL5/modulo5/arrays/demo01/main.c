#include  <stdio.h>
/*  prints the contents of a vector and the adresses  */
int main() 
{       int vec[3]={1,2,3}; 
	int i; 
	for(i=0;i<3;i++) 
		printf("vec[%d]=%d &vec[%d]=%p\n",i,vec[i],i,&vec[i]);
	printf("vec=%p\n",vec); 
	return 0; 
}
