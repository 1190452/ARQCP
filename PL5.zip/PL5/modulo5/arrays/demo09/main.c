#include  <stdio.h>
#include <stdlib.h>  
/*  using dynamic memory to place a vector  */ 
/*  the vector can be used as a "normal" vector  */

int main() 
{       int vec[3]={1,2,3}; 
	int i; 
	int *p; 
	p=malloc(3*sizeof(int)); 
	for(i=0;i<3;i++) 
		p[i]=vec[i]; 
	for(i=0;i<3;i++) 
		printf("p[%d]=%d &p[%d]=%p\n",i,p[i],i,&p[i]);
	free(p); 
	return 0; 
}
