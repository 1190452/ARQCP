#include  <stdio.h>
#include <stdlib.h>  
/*  the same thing with pointers and indirection   */

int main() 
{       int vec[3]={1,2,3}; 
	int i; 
	int *p[3]; 
	for(i=0;i<3;i++) {  
		p[i]=malloc(sizeof(int)); 
		**(p+i)=vec[i];
	        } 	
	for(i=0;i<3;i++){  
		printf("p[%d]=%p *p[%d]=%d\n",i,*(p+i),i ,**(p+i));
		free(p[i]);
	}    	
	return 0; 
}
