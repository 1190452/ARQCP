#include <stdio.h>
#include <string.h>
#include "asm.h"
#include <stdlib.h>


int main(void) {
  int  n = 3;
  unsigned char *space = (unsigned char*) malloc (3 *  sizeof(unsigned char));

  unsigned char grade_array [] = {1,2,3};
  unsigned char *grades = grade_array;
  group g1;
  group *g = &g1;

  g->n_students = n;
  g->individual_grades = grades;
  int result = 0;
  result = approved_semester(g);
  printf("%d\n", result);

  free(space);
  return 0;
}
