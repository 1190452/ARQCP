#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  Student s;
  

        int new_grades[] = {20, 15, 13, 0, 3, 2, 14, 8, 10, 12};

	Student* sPointer = &s;

	update_grades(sPointer, new_grades);

	return 0;
}
