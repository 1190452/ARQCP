#ifndef ASM_H
#define ASM_H
#include "struct.h" 
void update_grades(Student *s, int *new_grades);
#endif
