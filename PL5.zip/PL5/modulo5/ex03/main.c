#include <stdio.h>
#include <string.h>
#include "asm.h"
int main(void) {
  Student stu[5];
  Student * ptr;
  
  ptr = &stu[0];
  fill_student(ptr,19,27,"Bruno Pereira", "Espinho");

  printf("%d\n", ptr->age);
  printf("%d\n", ptr->number);
  printf("%s\n", ptr->name);
  printf("%s\n", ptr->address);

    printf("\n");

  ptr = &stu[1];
  fill_student(ptr,19,30,"Alexandre Rosa", "Povoa de Varzim");

  printf("%d\n", ptr->age);
  printf("%d\n", ptr->number);
  printf("%s\n", ptr->name);
  printf("%s\n", ptr->address);

    printf("\n");

  ptr = &stu[2];
  fill_student(ptr,19,22,"Afonso Bertao", "Vila");

  printf("%d\n", ptr->age);
  printf("%d\n", ptr->number);
  printf("%s\n", ptr->name);
  printf("%s\n", ptr->address);

    printf("\n");

  ptr = &stu[3];
  fill_student(ptr,19,7,"Ricardo Pereira", "Espinho");

  printf("%d\n", ptr->age);
  printf("%d\n", ptr->number);
  printf("%s\n", ptr->name);
  printf("%s\n", ptr->address);

    printf("\n");

  ptr = &stu[4];
  fill_student(ptr,19,12,"Guilherme Cota", "Porto");

  printf("%d\n", ptr->age);
  printf("%d\n", ptr->number);
  printf("%s\n", ptr->name);
  printf("%s\n", ptr->address);
  return 0;
}
